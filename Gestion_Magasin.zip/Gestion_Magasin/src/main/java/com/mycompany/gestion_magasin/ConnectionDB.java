/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.gestion_magasin;

import java.sql.DriverManager;
import java.sql.Connection;
import java.sql.SQLException;
import javax.swing.JOptionPane;

/**
 *
 * @author Student
 */
public class ConnectionDB {
    public static Connection getConnection(){
        Connection connection = null;
        try {
            connection =DriverManager.getConnection("jdbc:mysql://localhost:3306/employees", "root", "timodb2022");
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "connection failed");
            
        }
        return connection;
    }
    
}